#include <stdio.h>

void idle_fn (int a, int b){

	printf ("a = d---- b=d");

};
