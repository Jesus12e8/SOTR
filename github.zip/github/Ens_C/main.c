/**archivo con funcion mainpara llamar a la funcion 
 * funcion_exit*/

void main (void){

	int status = 255;
	funcion();
	funcion_exit (status);

}
