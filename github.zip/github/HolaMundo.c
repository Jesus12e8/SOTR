#include <stdio.h>

int main (int ar, char *arv[])
{
	printf("Hola Mundo C en GNU - linux!\n");
	return 0;
}
