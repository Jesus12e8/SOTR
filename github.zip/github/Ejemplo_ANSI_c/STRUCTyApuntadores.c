#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct boleta {
	int boleta;
	char nombre [100];
};

void mostrar (struct boleta *boletaPt);

int main (int argc, char *argv[]){

	struct boleta bolt1;
	struct boleta *bolpt = &bolt1;

	bolpt -> boleta = 2014640217;
      	strcpy(bolpt -> nombre, "Jesus Ramirez Perez");

	mostrar (bolpt);

//	free(bolpt);
	return 0;

}

//imprime en pantalla el numero de boleta y el nombre del alumno
void mostrar (struct boleta *boletaPt){
	printf ("%d\n",boletaPt->boleta);
        printf ("%s\n",boletaPt->nombre);
};

//biblioteca string
//str string cpu
//para ver numero de linea  esc + se nu
