int funcion1 (int enA){
	return (enA%7);
}
