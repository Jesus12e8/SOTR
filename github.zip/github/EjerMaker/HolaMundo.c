#include<stdio.h>

int main (){
	printf("HOLA MUNDO GNU-LINUX (SALA 2)!\n");
	char A = funcion();
	int B = A - funcion1(A);
	return (int)B;
}
